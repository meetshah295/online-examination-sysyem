from django.http.response import HttpResponseRedirect
from exam.models import student, teacher , result
from .forms import LoginForm , TeachLoginForm
from exam import models
from django.db import IntegrityError
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages

# Create your views here.
name = ""
def home(request):
    return render(request,'home.html')

def Student(request):
    return render(request,'base1.html')

def Teacher(request):
    return render(request,'Teacher.html')

def Exam(request):
    try:
        score=request.POST.get('score')
        print(score , name)
        score=str(score)
        result.objects.filter(student_name=name).update(score=score)
    except:
        pass
    return render(request,'Exam.html')

def CSS_exam(request):
    return render(request , 'CSS_exam.html')

def choose_exam(request):
    return render(request,'choose_exam.html')

def results(request):
    table=result.objects.all()
    return render(request, 'result.html', { 'table':table}  )

def user_login(request):
    return render(request, 'user_login.html')

def register(request):
    form = UserCreationForm()
    if request.method == 'POST':
        post = student()
        first_name=  request.POST.get('first_name')
        last_name=  request.POST.get('last_name')
        email=  request.POST.get('email')
        Branch=  request.POST.get('Branch')
        Year=  request.POST.get('Year')
        Password= request.POST.get('Password')
        ins = student(first_name=first_name, last_name=last_name, email=email, Branch=Branch, Year=Year, Password=Password)
        ins.save()
        print("the data has been written in database")
        return redirect('login')
    return render(request, 'register.html', {'form':form} )

def teacher_register(request):
    form = UserCreationForm()
    if request.method == 'POST':
        post = teacher()
        teacher_name=  request.POST.get('teacher_name')
        email=  request.POST.get('email')
        Designation=  request.POST.get('Designation')
        DOJ=  request.POST.get('DOJ')
        Teacher_Password= request.POST.get('Teacher_Password')
        ins = teacher(teacher_name=teacher_name, email=email, Designation=Designation, DOJ=DOJ, Teacher_Password=Teacher_Password)
        ins.save()
        print("the data has been written in database")
        return redirect('Teacher_login')
    return render(request, 'Teacher_register.html', {'form':form} )

def login(request):
    if request.method == 'POST':
        form = LoginForm(data = request.POST)
        if form.is_valid():
            first_name = request.POST.get('first_name')
            global name
            name = request.POST.get('first_name')
            print("login " , name)
            Password = request.POST.get('Password')
            if student.objects.filter(first_name__contains=first_name):
                if student.objects.filter(Password__contains=Password):
                    if result.objects.filter(student_name__contains=first_name):
                        print("Exam given")
                    else: 
                        name = first_name
                        print(name)
                        result.objects.create(student_name=first_name, score=0)
                        print(first_name, Password)
                        return redirect('choose_exam')
                else:
                    print("wrong username or password")
            else:
                print("wrong username or password")
            
    form = LoginForm()
    return render(request = request,
                    template_name = "login.html",
                    context={"form":form})

def Teacher_login(request):
    if request.method == 'POST':
        form = TeachLoginForm(data = request.POST)
        if form.is_valid():
            teacher_name = request.POST.get('teacher_name')
            Teacher_Password = request.POST.get('Teacher_Password')
            if teacher.objects.filter(teacher_name__contains=teacher_name):
                if teacher.objects.filter(Teacher_Password__contains=Teacher_Password):
                    print(teacher_name , Teacher_Password)
                    return redirect('/result')
                else:
                    print("wrong username or password")
            else:
                print("wrong username or password")
        else:  
            print("form not valid")       
    form = TeachLoginForm()
    return render(request = request,
                    template_name = "Teacher_login.html",
                    context={"form":form})

def Marks(request):
    print("This is ", name)
    marks = result.objects.filter(student_name__contains=name)
    return render(request , 'Marks.html' , {"name":name , "marks":marks[0].score} )





  
from django import forms
from .models import student

class Formstudent(forms.Form):
    name = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'id': 'name',
        'data-val': 'true',
        'data-val-required': 'Please enter name'
    }
    ))

class LoginForm(forms.Form):
    first_name = forms.CharField(max_length=20)
    Password = forms.CharField(widget=forms.PasswordInput())

class TeachLoginForm(forms.Form):
    teacher_name = forms.CharField(max_length=20)
    Teacher_Password = forms.CharField(widget=forms.PasswordInput())

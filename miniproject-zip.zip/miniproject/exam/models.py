from django.db import models


# Create your models here.
class student(models.Model):
    first_name= models.CharField(max_length=100)
    last_name= models.CharField(max_length=50)
    email= models.EmailField()
    Branch= models.CharField(max_length=200)
    Year= models.IntegerField()
    Password=models.CharField(max_length=50, default='')

    def __str__(self):
        return self.first_name

class teacher(models.Model):
    teacher_name= models.CharField(max_length=100)
    email= models.EmailField()
    Designation= models.CharField(max_length=200)
    DOJ= models.DateField()
    Teacher_Password=models.CharField(max_length=50, default='')

    def __str__(self):
        return self.teacher_name

class result(models.Model):
    student_name= models.CharField(max_length=100)
    score= models.IntegerField(max_length=100)
    

    def __str__(self):
        return self.student_name
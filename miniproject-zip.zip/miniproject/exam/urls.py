from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('miniproject/', views.home),
    path('register/',views.register),
    path('login/',views.login,name='login'),
    path('', views.home, name='homepage'),
    path('Student/',views.Student),
    path('Exam/',views.Exam, name='Exam'),
    path('/user_login/',views.user_login, name='user_login' ),
    path('Teacher_register/',views.teacher_register),
    path('Teacher/',views.Teacher),
    path('choose_exam/',views.choose_exam, name='choose_exam'),
    path('CSS_exam/', views.CSS_exam , name='CSS_exam'),
    path('Teacher_login/',views.Teacher_login , name='Teacher_login'),
    path('result/',views.results, name='result'),
    path('marks/',views.Marks , name='Marks')

]
